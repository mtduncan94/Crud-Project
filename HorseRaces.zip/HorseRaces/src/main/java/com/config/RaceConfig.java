package com.config;

import com.dao.RaceDAO;
import javax.sql.DataSource;
import org.springframework.context.annotation.*;import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
;

@Configuration
@ComponentScan({"com.controller"})
@EnableWebMvc
public class RaceConfig {
    
    
    @Bean
    public DataSource getDataSource(){
    DriverManagerDataSource dataSource = new DriverManagerDataSource();
    dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
    dataSource.setUrl("jdbc:mysql://localhost:3306/horseracedb");
    dataSource.setUsername("root");
    dataSource.setPassword("12@Pple$apple");
        return dataSource;
            }
    
   @Bean
    public RaceDAO getRaceDAO(){
    return new RaceDAO(getDataSource());
    }

}